import type { Metadata } from 'next'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { SITE_CONFIG, getWhatsAppLink } from '@/data/config'

export const metadata: Metadata = { title: 'Contact' }

export default function ContactPage() {
  const waLink = getWhatsAppLink(SITE_CONFIG.whatsappNumber, SITE_CONFIG.whatsappMessage)

  const channels = [
    {
      emoji: '💬',
      title: 'WhatsApp (recommandé)',
      sub: 'Réponse sous 24h',
      href: waLink,
    },
    {
      emoji: '📧',
      title: 'Email',
      sub: SITE_CONFIG.email,
      href: `mailto:${SITE_CONFIG.email}`,
    },
  ]

  return (
    <>
      <Header />
      <main style={{ padding: '80px 0' }}>
        <div className="container-site" style={{ maxWidth: 560, margin: '0 auto', textAlign: 'center' }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2, marginBottom: 14, textTransform: 'uppercase' }}>
            Contact
          </p>
          <h1 style={{ fontSize: 'clamp(26px,4vw,42px)', fontWeight: 900, color: '#fff', letterSpacing: '-.5px', marginBottom: 14 }}>
            Une question ?
          </h1>
          <p style={{ fontSize: 15, color: '#9CA3AF', lineHeight: 1.75, marginBottom: 44 }}>
            Notre équipe répond rapidement à toutes vos questions sur nos produits.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 44 }}>
            {channels.map(({ emoji, title, sub, href }) => (
              <a
                key={title}
                href={href}
                target="_blank"
                rel="noreferrer"
                style={{
                  background: '#0D1018', border: '1px solid rgba(255,255,255,.08)',
                  borderRadius: 14, padding: '22px 24px',
                  display: 'flex', alignItems: 'center', gap: 18,
                  textDecoration: 'none', color: 'inherit',
                  transition: 'border-color .2s',
                }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(30,94,255,.4)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,.08)')}
              >
                <span style={{ fontSize: 26 }}>{emoji}</span>
                <div style={{ textAlign: 'left', flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 3 }}>{title}</p>
                  <p style={{ fontSize: 12, color: '#6B7280' }}>{sub}</p>
                </div>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </a>
            ))}
          </div>

          <a href={waLink} target="_blank" rel="noreferrer" className="btn-blue btn-blue-xl">
            OUVRIR WHATSAPP →
          </a>
        </div>
      </main>
      <Footer />
    </>
  )
}
