import type { Metadata } from 'next'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { SITE_CONFIG } from '@/data/config'

export const metadata: Metadata = { title: 'Politique de confidentialité' }

// ── Modifier ce contenu librement ──────────────────────────
const sections = [
  {
    title: '1. Collecte des données',
    content: `${SITE_CONFIG.brandName} collecte uniquement les informations nécessaires au traitement de vos commandes et à votre support client. Ces informations peuvent inclure : nom, adresse email et numéro WhatsApp lorsque vous nous contactez.`,
  },
  {
    title: '2. Utilisation des données',
    content: `Vos données sont utilisées exclusivement pour : le traitement de vos commandes, l'envoi de vos produits numériques, le support client, et l'amélioration de nos services. Nous ne vendons ni ne partageons vos données avec des tiers à des fins commerciales.`,
  },
  {
    title: '3. Paiement',
    content: `Les paiements sont traités par Chariow, une plateforme de paiement sécurisée. ${SITE_CONFIG.brandName} ne stocke aucune information bancaire ou de carte de crédit.`,
  },
  {
    title: '4. Cookies',
    content: `Notre site utilise des cookies techniques nécessaires à son bon fonctionnement. Aucun cookie publicitaire ou de tracking tiers n'est utilisé.`,
  },
  {
    title: '5. Vos droits',
    content: `Vous disposez d'un droit d'accès, de rectification et de suppression de vos données personnelles. Pour exercer ces droits, contactez-nous via WhatsApp ou par email.`,
  },
  {
    title: '6. Contact',
    content: `Pour toute question relative à cette politique, contactez-nous à : ${SITE_CONFIG.email}`,
  },
]

export default function ConfidentialitePage() {
  return (
    <>
      <Header />
      <main style={{ padding: '80px 0' }}>
        <div className="container-site" style={{ maxWidth: 720, margin: '0 auto' }}>
          <h1 style={{ fontSize: 'clamp(24px,4vw,40px)', fontWeight: 900, color: '#fff', marginBottom: 12 }}>
            Politique de confidentialité
          </h1>
          <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 48 }}>
            Dernière mise à jour : {new Date().getFullYear()}
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {sections.map(({ title, content }) => (
              <div key={title} style={{ borderBottom: '1px solid rgba(255,255,255,.06)', paddingBottom: 32 }}>
                <h2 style={{ fontSize: 17, fontWeight: 700, color: '#fff', marginBottom: 12 }}>{title}</h2>
                <p style={{ fontSize: 14, color: '#9CA3AF', lineHeight: 1.85 }}>{content}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
