'use client'
import { useState, useRef } from 'react'
import { PRODUCTS } from '@/data/products'
import { CATEGORIES, ADMIN_PASSWORD } from '@/data/config'
import type { Product, Category } from '@/types'

// ── Page Admin — route /admin ─────────────────────────────────────
// Accès : protégé par mot de passe (défini dans .env.local)
// V1 : les modifications génèrent un fichier products.ts à télécharger
// V2 : connecter Supabase pour persistence sans redéploiement
// ──────────────────────────────────────────────────────────────────

const EMPTY_PRODUCT: Omit<Product, 'id'> = {
  title: '', slug: '', category: 'WHATSAPP & VENTE', badge: '',
  price: '', oldPrice: '', shortDesc: '', description: '',
  image: '', emoji: '📦', accroche: '', checkoutUrl: 'REMPLACER_PAR_MON_LIEN_CHARIOW',
  isDemo: false, benefits: [], contents: [],
}

const uid = () => Math.random().toString(36).slice(2, 9)

function toSlug(str: string) {
  return str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
}

// Génère le contenu du fichier products.ts exportable
function generateProductsTs(products: Product[]): string {
  const lines = products.map(p => `  {
    id:          '${p.id}',
    title:       '${p.title.replace(/'/g, "\\'")}',
    slug:        '${p.slug}',
    category:    '${p.category}' as Category,
    badge:       '${p.badge ?? ''}',
    price:       '${p.price}',
    oldPrice:    ${p.oldPrice ? `'${p.oldPrice}'` : 'undefined'},
    accroche:    '${(p.accroche ?? '').replace(/'/g, "\\'")}',
    shortDesc:   '${p.shortDesc.replace(/'/g, "\\'")}',
    description: \`${p.description.replace(/`/g, '\\`')}\`,
    image:       '${p.image ?? ''}',
    emoji:       '${p.emoji ?? '📦'}',
    checkoutUrl: '${p.checkoutUrl}',
    isDemo:      ${p.isDemo ?? false},
    benefits: [${(p.benefits ?? []).map(b => `\n      '${b.replace(/'/g, "\\'")}'`).join(',')}${(p.benefits ?? []).length ? '\n    ' : ''}],
    contents: [${(p.contents ?? []).map(c => `\n      '${c.replace(/'/g, "\\'")}'`).join(',')}${(p.contents ?? []).length ? '\n    ' : ''}],
  }`).join(',\n\n')

  return `// AUTO-GÉNÉRÉ PAR LE PANNEAU ADMIN — ${new Date().toLocaleDateString('fr-FR')}
// Remplacez le contenu de src/data/products.ts par ce fichier

import type { Product } from '@/types'
import type { Category } from '@/types'

export const PRODUCTS: Product[] = [
${lines}
]

export function getProductBySlug(slug: string): Product | undefined {
  return PRODUCTS.find(p => p.slug === slug)
}
export function getProductsByCategory(category: string): Product[] {
  if (category === 'TOUS') return PRODUCTS
  return PRODUCTS.filter(p => p.category === category)
}
export function isCheckoutValid(url: string): boolean {
  return !!(url && url !== '' && url !== '#' && url !== 'REMPLACER_PAR_MON_LIEN_CHARIOW')
}
`
}

// ── Formulaire produit ─────────────────────────────────────
function ProductForm({
  initial, onSave, onCancel,
}: {
  initial?: Product
  onSave: (p: Product) => void
  onCancel: () => void
}) {
  const [f, setF] = useState<Product>(initial ?? { id: uid(), ...EMPTY_PRODUCT })
  const imgRef = useRef<HTMLInputElement>(null)

  const set = (k: keyof Product, v: unknown) => setF(prev => ({ ...prev, [k]: v }))

  // Compression image en base64
  const handleImage = (file: File) => {
    const reader = new FileReader()
    reader.onload = e => {
      const img = new Image()
      img.onload = () => {
        const MAX = 900
        const scale = Math.min(MAX / img.width, MAX / img.height, 1)
        const canvas = document.createElement('canvas')
        canvas.width = img.width * scale
        canvas.height = img.height * scale
        canvas.getContext('2d')!.drawImage(img, 0, 0, canvas.width, canvas.height)
        set('image', canvas.toDataURL('image/jpeg', 0.82))
      }
      img.src = e.target!.result as string
    }
    reader.readAsDataURL(file)
  }

  const valid = f.title.trim() && f.price.trim() && f.shortDesc.trim()

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '20px 24px', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
        <button onClick={onCancel} style={{ color: '#9CA3AF', fontSize: 13, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6 }}>
          ← Retour
        </button>
        <h2 style={{ fontSize: 16, fontWeight: 800, color: '#fff', margin: 0 }}>
          {initial ? 'Modifier le produit' : 'Nouveau produit'}
        </h2>
      </div>

      <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>

        {/* Image */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 10, textTransform: 'uppercase' }}>
            Image du produit
          </label>
          <div
            onClick={() => imgRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); const file = e.dataTransfer.files[0]; if (file?.type.startsWith('image/')) handleImage(file) }}
            style={{
              border: '2px dashed rgba(255,255,255,.15)', borderRadius: 14, cursor: 'pointer',
              height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'rgba(255,255,255,.02)', position: 'relative', overflow: 'hidden',
              transition: 'border-color .2s',
            }}
          >
            {f.image
              ? <img src={f.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              : <div style={{ textAlign: 'center', pointerEvents: 'none' }}>
                  <p style={{ fontSize: 32, marginBottom: 8 }}>📸</p>
                  <p style={{ fontSize: 13, color: '#9CA3AF', fontWeight: 600 }}>Glissez votre image ou cliquez</p>
                  <p style={{ fontSize: 11, color: '#4B5563', marginTop: 4 }}>JPG, PNG — compressée automatiquement</p>
                </div>
            }
            <input ref={imgRef} type="file" accept="image/*" style={{ display: 'none' }}
              onChange={e => { const f = e.target.files?.[0]; if (f) handleImage(f) }} />
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
            <input
              className="form-input" placeholder="ou coller une URL d'image https://..."
              style={{ flex: 1, fontSize: 12 }}
              onChange={e => { if (e.target.value) set('image', e.target.value) }}
            />
            {f.image && (
              <button onClick={() => set('image', '')}
                style={{ padding: '8px 12px', borderRadius: 8, fontSize: 12, color: '#EF4444', background: 'rgba(239,68,68,.1)', border: '1px solid rgba(239,68,68,.2)' }}>
                Supprimer
              </button>
            )}
          </div>
        </div>

        {/* Titre */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Titre *
          </label>
          <input className="form-input" value={f.title}
            onChange={e => { set('title', e.target.value); if (!initial) set('slug', toSlug(e.target.value)) }}
            placeholder="WHATSAPP SALE SYSTÈME ™" />
        </div>

        {/* Slug */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Slug (URL) — /produits/<strong style={{ color: '#fff' }}>{f.slug || 'mon-produit'}</strong>
          </label>
          <input className="form-input" value={f.slug} onChange={e => set('slug', toSlug(e.target.value))} placeholder="whatsapp-sale-systeme" />
        </div>

        {/* Catégorie + Badge */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>Catégorie</label>
            <select className="form-input" value={f.category} onChange={e => set('category', e.target.value as Category)}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>Badge</label>
            <select className="form-input" value={f.badge ?? ''} onChange={e => set('badge', e.target.value)}>
              {['', 'PRODUIT PHARE', 'NOUVEAU', 'BESTSELLER', 'PROMO', 'BUNDLE'].map(b => (
                <option key={b} value={b}>{b || '— aucun —'}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Description courte */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Description courte * <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(carte produit)</span>
          </label>
          <textarea className="form-input" rows={3} value={f.shortDesc} onChange={e => set('shortDesc', e.target.value)}
            placeholder="Le système complet pour transformer WhatsApp en machine à vendre..." style={{ resize: 'vertical' }} />
        </div>

        {/* Description complète */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Description complète <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(fiche produit)</span>
          </label>
          <textarea className="form-input" rows={5} value={f.description} onChange={e => set('description', e.target.value)}
            placeholder="Description détaillée..." style={{ resize: 'vertical' }} />
        </div>

        {/* Prix */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>Prix *</label>
            <input className="form-input" value={f.price} onChange={e => set('price', e.target.value)} placeholder="4 700 FCFA" />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>Ancien prix <span style={{ fontWeight: 400 }}>(barré)</span></label>
            <input className="form-input" value={f.oldPrice ?? ''} onChange={e => set('oldPrice', e.target.value)} placeholder="6 000 FCFA" />
          </div>
        </div>

        {/* Checkout URL */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Lien de paiement Chariow
          </label>
          <input className="form-input" value={f.checkoutUrl} onChange={e => set('checkoutUrl', e.target.value)}
            placeholder="https://chariow.com/checkout/mon-produit" type="url" />
          <p style={{ fontSize: 11, color: '#4B5563', marginTop: 6 }}>Ce lien s&apos;ouvre quand le client clique &ldquo;ACHETER MAINTENANT&rdquo;</p>
        </div>

        {/* Bénéfices */}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', letterSpacing: .5, display: 'block', marginBottom: 8, textTransform: 'uppercase' }}>
            Bénéfices <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(un par ligne)</span>
          </label>
          <textarea className="form-input" rows={5} value={(f.benefits ?? []).join('\n')}
            onChange={e => set('benefits', e.target.value.split('\n').filter(Boolean))}
            placeholder={'Bénéfice 1\nBénéfice 2\nBénéfice 3'} style={{ resize: 'vertical' }} />
        </div>

        {/* Boutons */}
        <div style={{ display: 'flex', gap: 12, paddingTop: 8 }}>
          <button className="btn-ghost" style={{ flex: 1, padding: '14px 0' }} onClick={onCancel}>Annuler</button>
          <button
            style={{
              flex: 2, padding: '14px 0', fontSize: 14, gap: 8,
              background: valid ? '#1E5EFF' : 'rgba(30,94,255,.3)',
              color: '#fff', border: 'none', borderRadius: 10,
              fontWeight: 700, cursor: valid ? 'pointer' : 'not-allowed',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
            disabled={!valid}
            onClick={() => valid && onSave(f)}
          >
            💾 Sauvegarder
          </button>
        </div>
        {!valid && <p style={{ fontSize: 11, color: '#EF4444', textAlign: 'center' }}>Titre, prix et description courte sont obligatoires.</p>}
      </div>
    </div>
  )
}

// ── Page principale Admin ──────────────────────────────────
export default function AdminPage() {
  const [pw, setPw] = useState('')
  const [auth, setAuth] = useState(false)
  const [wrongPw, setWrongPw] = useState(false)
  const [products, setProducts] = useState<Product[]>(PRODUCTS)
  const [view, setView] = useState<'list' | 'add' | 'edit'>('list')
  const [editTarget, setEditTarget] = useState<Product | null>(null)
  const [confirmDel, setConfirmDel] = useState<string | null>(null)
  const [exported, setExported] = useState(false)

  const login = () => {
    if (pw === ADMIN_PASSWORD) { setAuth(true); setWrongPw(false) }
    else { setWrongPw(true) }
  }

  const downloadFile = () => {
    const content = generateProductsTs(products)
    const blob = new Blob([content], { type: 'text/typescript' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'products.ts'
    a.click()
    setExported(true)
    setTimeout(() => setExported(false), 3000)
  }

  // ── Écran connexion ────────────────────────────────────────
  if (!auth) {
    return (
      <div style={{
        minHeight: '100vh', background: '#0A0A0A',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          background: '#0D1018', border: '1px solid rgba(255,255,255,.08)',
          borderRadius: 20, padding: 40, width: 360, textAlign: 'center',
        }}>
          <p style={{ fontSize: 32, marginBottom: 16 }}>🔐</p>
          <h1 style={{ fontSize: 20, fontWeight: 900, color: '#fff', marginBottom: 8 }}>Espace Admin</h1>
          <p style={{ fontSize: 13, color: '#6B7280', marginBottom: 28 }}>ECOM-ROUFF DIGITAL UNIVERSE</p>
          <input
            className="form-input" type="password"
            placeholder="Mot de passe"
            value={pw}
            onChange={e => setPw(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && login()}
            style={{ marginBottom: 12 }}
          />
          {wrongPw && <p style={{ fontSize: 12, color: '#EF4444', marginBottom: 12 }}>Mot de passe incorrect.</p>}
          <button className="btn-blue" style={{ width: '100%', padding: '13px 0' }} onClick={login}>
            SE CONNECTER
          </button>
          <p style={{ fontSize: 11, color: '#374151', marginTop: 16, lineHeight: 1.6 }}>
            Mot de passe défini dans .env.local<br/>
            <code style={{ fontSize: 10 }}>NEXT_PUBLIC_ADMIN_PASSWORD</code>
          </p>
        </div>
      </div>
    )
  }

  // ── Formulaire ajout / édition ─────────────────────────────
  if (view === 'add') {
    return (
      <div style={{ minHeight: '100vh', background: '#0A0A0A' }}>
        <div style={{ maxWidth: 600, margin: '0 auto', padding: '0 0 80px' }}>
          <ProductForm
            onSave={p => { setProducts(prev => [p, ...prev]); setView('list') }}
            onCancel={() => setView('list')}
          />
        </div>
      </div>
    )
  }

  if (view === 'edit' && editTarget) {
    return (
      <div style={{ minHeight: '100vh', background: '#0A0A0A' }}>
        <div style={{ maxWidth: 600, margin: '0 auto', padding: '0 0 80px' }}>
          <ProductForm
            initial={editTarget}
            onSave={p => { setProducts(prev => prev.map(x => x.id === p.id ? p : x)); setView('list') }}
            onCancel={() => { setView('list'); setEditTarget(null) }}
          />
        </div>
      </div>
    )
  }

  // ── Liste produits ──────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', background: '#0A0A0A', padding: '40px 24px' }}>
      <div style={{ maxWidth: 800, margin: '0 auto' }}>

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32, flexWrap: 'wrap', gap: 16 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 900, color: '#fff', margin: 0 }}>⚙️ Gestion des produits</h1>
            <p style={{ fontSize: 13, color: '#6B7280', marginTop: 4 }}>
              {products.length} produit{products.length > 1 ? 's' : ''} au catalogue
            </p>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <a href="/" className="btn-ghost" style={{ padding: '10px 18px', fontSize: 13 }}>
              ← Voir le site
            </a>
            <button onClick={() => setAuth(false)} style={{ padding: '10px 14px', borderRadius: 10, fontSize: 12, color: '#9CA3AF', background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)' }}>
              Déconnexion
            </button>
          </div>
        </div>

        {/* Bannière export */}
        <div style={{
          background: 'rgba(30,94,255,.08)', border: '1px solid rgba(30,94,255,.25)',
          borderRadius: 14, padding: '20px 24px', marginBottom: 24,
        }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 8 }}>
            💾 Comment publier vos modifications ?
          </h3>
          <p style={{ fontSize: 13, color: '#9CA3AF', lineHeight: 1.6, marginBottom: 16 }}>
            <strong style={{ color: '#fff' }}>V1 :</strong> Après avoir ajouté/modifié vos produits ici, cliquez sur &ldquo;Télécharger products.ts&rdquo;, puis remplacez le fichier <code style={{ color: '#93C5FD' }}>src/data/products.ts</code> dans votre dépôt GitHub. Netlify redéploie automatiquement.<br/>
            <strong style={{ color: '#fff' }}>V2 :</strong> Connecter Supabase pour une mise à jour instantanée sans redéploiement.
          </p>
          <button
            onClick={downloadFile}
            style={{
              padding: '10px 20px', background: exported ? '#16A34A' : '#1E5EFF',
              color: '#fff', border: 'none', borderRadius: 10,
              fontWeight: 700, fontSize: 13, cursor: 'pointer', transition: 'background .2s',
            }}
          >
            {exported ? '✅ Téléchargé !' : '⬇️ Télécharger products.ts'}
          </button>
        </div>

        {/* Bouton ajouter */}
        <button
          className="btn-blue"
          style={{ width: '100%', padding: '14px 0', fontSize: 14, marginBottom: 24 }}
          onClick={() => setView('add')}
        >
          ➕ Ajouter un nouveau produit / ebook
        </button>

        {/* Liste */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {products.map(p => (
            <div key={p.id} style={{
              display: 'flex', alignItems: 'center', gap: 16,
              padding: '16px 20px',
              background: '#0D1018', borderRadius: 12,
              border: '1px solid rgba(255,255,255,.06)',
            }}>
              {/* Mini image */}
              <div style={{
                width: 54, height: 54, borderRadius: 10, flexShrink: 0, overflow: 'hidden',
                background: p.image ? `url(${p.image}) center/cover` : 'linear-gradient(135deg,#1E0A3C,#1E5EFF)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
              }}>
                {!p.image && (p.emoji ?? '📦')}
              </div>

              {/* Infos */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 14, fontWeight: 700, color: '#fff', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {p.title}
                </p>
                <p style={{ fontSize: 12, color: '#1E5EFF', fontWeight: 600, marginTop: 2 }}>
                  {p.price}
                  {p.isDemo && <span style={{ color: '#6B7280', marginLeft: 8 }}>— DÉMO</span>}
                </p>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                <button
                  onClick={() => { setEditTarget(p); setView('edit') }}
                  style={{ padding: '7px 12px', borderRadius: 8, fontSize: 12, fontWeight: 600, background: 'rgba(255,255,255,.06)', color: '#9CA3AF', border: '1px solid rgba(255,255,255,.1)', cursor: 'pointer' }}
                >
                  ✏️ Modifier
                </button>
                {confirmDel === p.id ? (
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button
                      onClick={() => { setProducts(prev => prev.filter(x => x.id !== p.id)); setConfirmDel(null) }}
                      style={{ padding: '7px 10px', borderRadius: 8, fontSize: 11, fontWeight: 700, background: '#EF4444', color: '#fff', border: 'none', cursor: 'pointer' }}
                    >Confirmer</button>
                    <button
                      onClick={() => setConfirmDel(null)}
                      style={{ padding: '7px 10px', borderRadius: 8, fontSize: 11, background: 'rgba(255,255,255,.06)', color: '#9CA3AF', border: '1px solid rgba(255,255,255,.1)', cursor: 'pointer' }}
                    >Non</button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDel(p.id)}
                    style={{ padding: '7px 10px', borderRadius: 8, fontSize: 12, background: 'rgba(239,68,68,.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,.2)', cursor: 'pointer' }}
                  >🗑️</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
