import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import Link from 'next/link'
import { PRODUCTS, getProductBySlug, isCheckoutValid } from '@/data/products'
import { BADGE_COLORS, SITE_CONFIG } from '@/data/config'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import ProductImage from '@/components/ProductImage'
import WASection from '@/components/WASection'

// Génère les routes statiques pour chaque slug
export async function generateStaticParams() {
  return PRODUCTS.map(p => ({ slug: p.slug }))
}

// Métadonnées dynamiques
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = getProductBySlug(params.slug)
  if (!product) return { title: 'Produit introuvable' }
  return {
    title: product.title,
    description: product.shortDesc,
    openGraph: {
      title: product.title,
      description: product.shortDesc,
      images: product.image ? [{ url: product.image }] : [],
    },
  }
}

export default function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = getProductBySlug(params.slug)
  if (!product) notFound()

  const badgeColor = product.badge ? (BADGE_COLORS[product.badge] ?? '#3B82F6') : null
  const canBuy = !product.isDemo && isCheckoutValid(product.checkoutUrl)

  return (
    <>
      <Header />
      <main style={{ padding: '0 0 80px' }}>
        <div className="container-site">

          {/* Fil d'Ariane */}
          <div style={{ padding: '28px 0', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
            <Link href="/produits" className="nav-link" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
              Retour aux produits
            </Link>
            <span style={{ color: '#374151' }}>/</span>
            <span style={{ color: '#6B7280' }}>{product.title}</span>
          </div>

          {/* Layout produit */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'start' }}
               className="md:grid-cols-2">

            {/* Colonne image */}
            <div>
              <div style={{ borderRadius: 20, overflow: 'hidden', marginBottom: 16 }}>
                <ProductImage product={product} height="380px" />
              </div>
              {product.isDemo && (
                <div style={{
                  background: 'rgba(107,114,128,.1)', border: '1px solid rgba(107,114,128,.2)',
                  borderRadius: 12, padding: '14px 18px', fontSize: 13, color: '#6B7280', lineHeight: 1.6,
                }}>
                  ⚠️ Ce produit est une démonstration — il n&apos;est pas disponible à l&apos;achat.
                </div>
              )}
            </div>

            {/* Colonne infos */}
            <div>
              {/* Catégorie + Badge */}
              <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
                <span style={{ fontSize: 10, fontWeight: 700, color: '#6B7280', letterSpacing: 1, textTransform: 'uppercase' }}>
                  {product.category}
                </span>
                {product.badge && badgeColor && (
                  <span style={{
                    fontSize: 10, fontWeight: 800, letterSpacing: 1, padding: '3px 9px',
                    borderRadius: 50, textTransform: 'uppercase',
                    background: `${badgeColor}22`, color: badgeColor, border: `1px solid ${badgeColor}44`,
                  }}>
                    {product.badge}
                  </span>
                )}
              </div>

              {/* Titre */}
              <h1 style={{
                fontSize: 'clamp(22px,3vw,36px)', fontWeight: 900, color: '#fff',
                letterSpacing: '-.5px', lineHeight: 1.2, marginBottom: 14,
              }}>
                {product.title}
              </h1>

              {/* Accroche */}
              {product.accroche && (
                <p style={{ fontSize: 15, fontWeight: 600, color: '#1E5EFF', marginBottom: 20, fontStyle: 'italic' }}>
                  &ldquo;{product.accroche}&rdquo;
                </p>
              )}

              {/* Description */}
              <div style={{ fontSize: 14, color: '#9CA3AF', lineHeight: 1.85, marginBottom: 32, whiteSpace: 'pre-line' }}>
                {product.description}
              </div>

              {/* Encart prix + CTA */}
              <div style={{
                background: '#0D1018', border: '1px solid rgba(255,255,255,.08)',
                borderRadius: 16, padding: 28, marginBottom: 28,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
                  <span style={{ fontSize: 30, fontWeight: 900, color: '#fff' }}>{product.price}</span>
                  {product.oldPrice && (
                    <span style={{ fontSize: 16, color: '#6B7280', textDecoration: 'line-through' }}>
                      {product.oldPrice}
                    </span>
                  )}
                </div>

                {canBuy ? (
                  <a
                    href={product.checkoutUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-blue btn-blue-xl"
                    style={{ width: '100%', marginBottom: 10 }}
                  >
                    ACHETER MAINTENANT →
                  </a>
                ) : (
                  <button
                    disabled
                    className="btn-blue btn-blue-xl"
                    style={{ width: '100%', marginBottom: 10, opacity: .4, cursor: 'not-allowed' }}
                  >
                    {product.isDemo ? 'PRODUIT DÉMO' : 'LIEN DE PAIEMENT NON CONFIGURÉ'}
                  </button>
                )}

                <p style={{ fontSize: 11, color: '#4B5563', textAlign: 'center' }}>
                  {canBuy
                    ? 'Paiement sécurisé via Chariow • Accès immédiat après paiement'
                    : product.isDemo
                      ? 'Ce produit est une démonstration.'
                      : 'Configurez checkoutUrl dans src/data/products.ts'
                  }
                </p>
              </div>

              {/* Bénéfices */}
              {product.benefits && product.benefits.length > 0 && (
                <div>
                  <h3 style={{ fontSize: 15, fontWeight: 800, color: '#fff', marginBottom: 14 }}>
                    Ce que vous allez maîtriser
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {product.benefits.map((b, i) => (
                      <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 2 }}>
                          <polyline points="20,6 9,17 4,12"/>
                        </svg>
                        <span style={{ fontSize: 13, color: '#D1D5DB', lineHeight: 1.6 }}>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Contenu du programme */}
          {product.contents && product.contents.length > 0 && (
            <div style={{
              marginTop: 56, background: '#0D1018', border: '1px solid rgba(255,255,255,.07)',
              borderRadius: 20, padding: 40,
            }}>
              <h2 style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 28 }}>
                Contenu du programme
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
                {product.contents.map((c, i) => (
                  <div key={i} style={{
                    background: 'rgba(255,255,255,.03)', border: '1px solid rgba(255,255,255,.06)',
                    borderRadius: 10, padding: '13px 16px', fontSize: 13, color: '#D1D5DB', lineHeight: 1.5,
                  }}>
                    {c}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CTA final */}
          {canBuy && (
            <div style={{ textAlign: 'center', marginTop: 64 }}>
              <h2 style={{ fontSize: 26, fontWeight: 900, color: '#fff', marginBottom: 10 }}>
                Prêt à passer à l&apos;action ?
              </h2>
              <p style={{ fontSize: 15, color: '#6B7280', marginBottom: 28 }}>
                Accès immédiat après votre paiement.
              </p>
              <a
                href={product.checkoutUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-blue btn-blue-xl"
              >
                ACHETER {product.title} — {product.price} →
              </a>
            </div>
          )}
        </div>

        <div style={{ marginTop: 72 }}>
          <WASection />
        </div>
      </main>
      <Footer />

      {/* Responsive */}
      <style>{`
        @media (max-width: 768px) {
          .product-detail-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </>
  )
}
