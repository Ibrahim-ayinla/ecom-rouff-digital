'use client'
import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import { PRODUCTS } from '@/data/products'
import { CATEGORIES } from '@/data/config'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import ProductCard from '@/components/ProductCard'
import WASection from '@/components/WASection'

export default function ProduitsPage() {
  const searchParams = useSearchParams()
  const [activeCat, setActiveCat] = useState('TOUS')

  // Lire le paramètre ?cat= dans l'URL
  useEffect(() => {
    const cat = searchParams.get('cat')
    if (cat && ([...CATEGORIES] as string[]).includes(cat)) {
      setActiveCat(cat)
    }
  }, [searchParams])

  const filtered = activeCat === 'TOUS'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === activeCat)

  return (
    <>
      <Header />
      <main>
        <section style={{ padding: '72px 0' }}>
          <div className="container-site">

            {/* En-tête */}
            <div style={{ marginBottom: 48 }}>
              <p style={{ fontSize: 11, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2, marginBottom: 12, textTransform: 'uppercase' }}>
                Catalogue complet
              </p>
              <h1 style={{ fontSize: 'clamp(26px,4vw,42px)', fontWeight: 900, color: '#fff', letterSpacing: '-.5px', marginBottom: 12 }}>
                Tous les produits
              </h1>
              <p style={{ fontSize: 14, color: '#6B7280', maxWidth: 460, lineHeight: 1.7 }}>
                Parcourez l&apos;ensemble de nos ressources digitales. Filtrez par catégorie pour trouver rapidement ce qu&apos;il vous faut.
              </p>
            </div>

            {/* Filtres catégories */}
            <div className="flex flex-wrap gap-2.5 mb-12">
              <button className={`pill ${activeCat === 'TOUS' ? 'active' : ''}`} onClick={() => setActiveCat('TOUS')}>
                TOUS
              </button>
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  className={`pill ${activeCat === cat ? 'active' : ''}`}
                  onClick={() => setActiveCat(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Grille produits */}
            {filtered.length > 0 ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
                {filtered.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '80px 0', color: '#4B5563' }}>
                <p style={{ fontSize: 40, marginBottom: 12 }}>📦</p>
                <p style={{ fontSize: 15 }}>Aucun produit dans cette catégorie pour le moment.</p>
              </div>
            )}
          </div>
        </section>

        <WASection />
      </main>
      <Footer />
    </>
  )
}
