import type { Metadata } from 'next'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { SITE_CONFIG } from '@/data/config'

export const metadata: Metadata = { title: 'À propos' }

export default function AboutPage() {
  return (
    <>
      <Header />
      <main style={{ padding: '80px 0' }}>
        <div className="container-site" style={{ maxWidth: 720, margin: '0 auto' }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2, marginBottom: 14, textTransform: 'uppercase' }}>
            Notre histoire
          </p>
          <h1 style={{ fontSize: 'clamp(26px,4vw,44px)', fontWeight: 900, color: '#fff', letterSpacing: '-.5px', marginBottom: 24, lineHeight: 1.15 }}>
            À propos d&apos;{SITE_CONFIG.brandName}
          </h1>
          <p style={{ fontSize: 16, color: '#9CA3AF', lineHeight: 1.85, marginBottom: 24 }}>
            {SITE_CONFIG.brandName} DIGITAL UNIVERSE est une boutique de ressources digitales pensée pour les entrepreneurs africains francophones. Notre mission est simple : vous donner les outils, guides et systèmes pour transformer vos idées en opportunités réelles.
          </p>
          <p style={{ fontSize: 16, color: '#9CA3AF', lineHeight: 1.85, marginBottom: 52 }}>
            Chaque produit est conçu pour être immédiatement applicable — pas de théorie creuse, mais des systèmes éprouvés adaptés aux réalités du marché africain.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 }}>
            {[
              ['🎯', 'Mission', "Démocratiser l'accès aux meilleures ressources business pour l'Afrique francophone."],
              ['🌍', 'Vision', "Devenir la référence des ressources digitales premium en Afrique de l'Ouest."],
              ['💡', 'Approche', "Des contenus actionnables, concrets et adaptés aux réalités locales."],
              ['🤝', 'Engagement', "Qualité premium, support réactif, satisfaction garantie."],
            ].map(([e, t, d]) => (
              <div key={t as string} style={{ background: '#0D1018', border: '1px solid rgba(255,255,255,.07)', borderRadius: 16, padding: 24 }}>
                <p style={{ fontSize: 26, marginBottom: 10 }}>{e}</p>
                <p style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 6 }}>{t}</p>
                <p style={{ fontSize: 13, color: '#6B7280', lineHeight: 1.65 }}>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
