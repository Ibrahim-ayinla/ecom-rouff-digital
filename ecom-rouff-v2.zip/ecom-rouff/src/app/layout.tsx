import type { Metadata } from 'next'
import './globals.css'
import { SITE_CONFIG } from '@/data/config'

export const metadata: Metadata = {
  title: {
    default: SITE_CONFIG.seoTitle,
    template: `%s | ${SITE_CONFIG.brandName}`,
  },
  description: SITE_CONFIG.seoDescription,
  keywords:    SITE_CONFIG.seoKeywords,
  openGraph: {
    title:       SITE_CONFIG.seoTitle,
    description: SITE_CONFIG.seoDescription,
    url:         SITE_CONFIG.siteUrl,
    siteName:    SITE_CONFIG.brandName,
    locale:      'fr_FR',
    type:        'website',
  },
  twitter: {
    card:        'summary_large_image',
    title:       SITE_CONFIG.seoTitle,
    description: SITE_CONFIG.seoDescription,
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  )
}
