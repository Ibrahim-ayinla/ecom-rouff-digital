import type { Metadata } from 'next'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { SITE_CONFIG } from '@/data/config'

export const metadata: Metadata = { title: "Conditions d'utilisation" }

const sections = [
  {
    title: '1. Produits numériques',
    content: `Les produits vendus sur ${SITE_CONFIG.brandName} sont des produits numériques (ebooks, guides, formations). Après paiement, vous recevez un accès immédiat à votre contenu. En raison de la nature numérique des produits, aucun remboursement n'est accordé sauf en cas d'erreur avérée de notre part.`,
  },
  {
    title: '2. Utilisation du contenu',
    content: `Tout contenu acheté est destiné à un usage personnel. Il est strictement interdit de reproduire, revendre, partager ou distribuer tout ou partie du contenu sans autorisation écrite préalable.`,
  },
  {
    title: '3. Exactitude des informations',
    content: `Nous nous efforçons de fournir des informations exactes et à jour. Cependant, ${SITE_CONFIG.brandName} ne peut être tenu responsable des décisions prises sur la base de nos contenus.`,
  },
  {
    title: '4. Prix',
    content: `Les prix sont indiqués en FCFA et sont susceptibles d'être modifiés sans préavis. Le prix applicable est celui affiché au moment de la commande.`,
  },
  {
    title: '5. Propriété intellectuelle',
    content: `Tous les contenus de ${SITE_CONFIG.brandName} (textes, images, logos, produits) sont protégés par le droit d'auteur. Toute reproduction non autorisée est interdite.`,
  },
  {
    title: '6. Contact',
    content: `Pour toute question relative à ces conditions : ${SITE_CONFIG.email}`,
  },
]

export default function ConditionsPage() {
  return (
    <>
      <Header />
      <main style={{ padding: '80px 0' }}>
        <div className="container-site" style={{ maxWidth: 720, margin: '0 auto' }}>
          <h1 style={{ fontSize: 'clamp(24px,4vw,40px)', fontWeight: 900, color: '#fff', marginBottom: 12 }}>
            {"Conditions d'utilisation"}
          </h1>
          <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 48 }}>
            Dernière mise à jour : {new Date().getFullYear()}
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {sections.map(({ title, content }) => (
              <div key={title} style={{ borderBottom: '1px solid rgba(255,255,255,.06)', paddingBottom: 32 }}>
                <h2 style={{ fontSize: 17, fontWeight: 700, color: '#fff', marginBottom: 12 }}>{title}</h2>
                <p style={{ fontSize: 14, color: '#9CA3AF', lineHeight: 1.85 }}>{content}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
