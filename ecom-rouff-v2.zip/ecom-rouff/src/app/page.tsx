import Link from 'next/link'
import type { Metadata } from 'next'
import { PRODUCTS } from '@/data/products'
import { SITE_CONFIG } from '@/data/config'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import ProductCard from '@/components/ProductCard'
import ProductImage from '@/components/ProductImage'
import WASection from '@/components/WASection'

export const metadata: Metadata = {
  title: SITE_CONFIG.seoTitle,
  description: SITE_CONFIG.seoDescription,
}

export default function HomePage() {
  const featured  = PRODUCTS.find(p => p.badge === 'PRODUIT PHARE') ?? PRODUCTS[0]
  const secondary = PRODUCTS[1]
  const third     = PRODUCTS[2]
  const recent    = PRODUCTS.slice(0, 6)

  return (
    <>
      <Header />
      <main>
        {/* ── HERO ─────────────────────────────────────────── */}
        <section
          style={{
            minHeight: '90vh',
            display: 'flex',
            alignItems: 'center',
            position: 'relative',
            overflow: 'hidden',
            background: 'radial-gradient(ellipse 80% 60% at 70% 50%, rgba(30,94,255,.13) 0%, transparent 65%)',
            borderBottom: '1px solid rgba(255,255,255,.05)',
          }}
        >
          {/* Grille de fond */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),' +
                'linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px)',
              backgroundSize: '60px 60px',
            }}
          />

          <div
            className="container-site w-full"
            style={{ padding: '80px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, alignItems: 'center' }}
          >
            {/* Texte */}
            <div>
              <div className="animate-fade-up mb-5">
                <span
                  style={{
                    display: 'inline-block', fontSize: 10, fontWeight: 800, letterSpacing: 1,
                    padding: '4px 12px', borderRadius: 50, textTransform: 'uppercase',
                    background: 'rgba(30,94,255,.15)', color: '#3B82F6', border: '1px solid rgba(30,94,255,.3)',
                  }}
                >
                  Boutique Digitale — Afrique Francophone
                </span>
              </div>

              <h1
                className="animate-fade-up-2"
                style={{
                  fontSize: 'clamp(34px,5vw,60px)', fontWeight: 900, lineHeight: 1.08,
                  letterSpacing: '-1.5px', color: '#fff', marginBottom: 24,
                }}
              >
                Transforme tes idées en{' '}
                <span style={{ color: '#1E5EFF' }}>opportunités</span>{' '}
                digitales.
              </h1>

              <p className="animate-fade-up-3" style={{ fontSize: 17, color: '#9CA3AF', lineHeight: 1.75, marginBottom: 40, maxWidth: 500 }}>
                Découvrez des ebooks, guides et ressources pratiques conçus pour développer votre business, mieux gérer votre argent et exploiter les opportunités du digital.
              </p>

              <div className="animate-fade-up-4 flex gap-4 flex-wrap">
                <Link href="/produits" className="btn-blue btn-blue-lg">
                  DÉCOUVRIR LES PRODUITS
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </Link>
                <Link href="/produits" className="btn-ghost btn-ghost-lg">
                  EXPLORER LA BOUTIQUE
                </Link>
              </div>

              <div className="animate-fade-up-5 flex gap-10 mt-12">
                {[[`${PRODUCTS.filter(p => !p.isDemo).length}+`, 'Produits'], ['100%', 'Digital'], ['Afrique', 'Francophone']].map(([n, l]) => (
                  <div key={l}>
                    <p style={{ fontSize: 26, fontWeight: 900, color: '#fff', lineHeight: 1 }}>{n}</p>
                    <p style={{ fontSize: 12, color: '#6B7280', marginTop: 4, letterSpacing: .4 }}>{l}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Visuel hero */}
            <div
              className="relative hidden md:flex items-center justify-center"
              style={{ height: 460 }}
            >
              <div
                className="absolute inset-0 pointer-events-none"
                style={{ background: 'radial-gradient(circle at 50% 50%, rgba(30,94,255,.28) 0%, transparent 65%)' }}
              />

              {/* Carte principale flottante */}
              {featured && (
                <Link
                  href={`/produits/${featured.slug}`}
                  className="animate-float relative z-30"
                  style={{
                    borderRadius: 18, width: 230, textAlign: 'center',
                    boxShadow: '0 40px 80px rgba(0,0,0,.6),0 0 60px rgba(30,94,255,.35),0 0 0 1px rgba(255,255,255,.1)',
                    overflow: 'hidden', display: 'block',
                  }}
                >
                  <ProductImage product={featured} height="300px" />
                </Link>
              )}

              {/* Carte secondaire */}
              {secondary && (
                <div
                  className="animate-float-2 absolute z-20"
                  style={{
                    top: '8%', right: '2%',
                    background: '#0D1018', border: '1px solid rgba(30,94,255,.22)',
                    borderRadius: 14, padding: '18px 20px', width: 148,
                    boxShadow: '0 20px 40px rgba(0,0,0,.5)',
                  }}
                >
                  <p style={{ fontSize: 24, marginBottom: 8 }}>{secondary.emoji ?? '📦'}</p>
                  <p style={{ fontSize: 11, fontWeight: 700, color: '#fff', marginBottom: 4 }}>{secondary.category}</p>
                  <p style={{ fontSize: 10, color: '#6B7280' }}>{secondary.price}</p>
                </div>
              )}

              {/* Troisième carte */}
              {third && (
                <div
                  className="animate-float-3 absolute z-20"
                  style={{
                    bottom: '8%', left: '0%',
                    background: '#0D1018', border: '1px solid rgba(16,185,129,.22)',
                    borderRadius: 14, padding: '16px 18px', width: 140,
                    boxShadow: '0 20px 40px rgba(0,0,0,.5)',
                  }}
                >
                  <p style={{ fontSize: 22, marginBottom: 6 }}>{third.emoji ?? '📦'}</p>
                  <p style={{ fontSize: 11, fontWeight: 700, color: '#fff', marginBottom: 4 }}>
                    {third.title.length > 18 ? third.title.slice(0, 18) + '…' : third.title}
                  </p>
                  <p style={{ fontSize: 10, color: '#10B981', fontWeight: 600 }}>{third.price}</p>
                </div>
              )}
            </div>
          </div>

          {/* Responsive hero */}
          <style>{`
            @media (max-width: 768px) {
              .hero-text-col { grid-template-columns: 1fr !important; }
            }
          `}</style>
        </section>

        {/* ── NOUVEAUTÉS ─────────────────────────────────── */}
        <section style={{ padding: '72px 0', borderBottom: '1px solid rgba(255,255,255,.05)' }}>
          <div className="container-site">
            <div style={{ marginBottom: 44 }}>
              <p style={{ fontSize: 11, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2, marginBottom: 10, textTransform: 'uppercase' }}>
                Boutique
              </p>
              <h2 style={{ fontSize: 'clamp(24px,4vw,36px)', fontWeight: 900, color: '#fff', letterSpacing: '-.5px', marginBottom: 10 }}>
                Les nouveautés
              </h2>
              <p style={{ fontSize: 14, color: '#6B7280', maxWidth: 460 }}>
                Découvrez les dernières ressources ajoutées à ECOM-ROUFF.
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
              {recent.map(p => <ProductCard key={p.id} product={p} />)}
            </div>

            <div className="text-center mt-12">
              <Link href="/produits" className="btn-ghost btn-ghost-lg">
                Voir tous les produits →
              </Link>
            </div>
          </div>
        </section>

        {/* ── PITCH ──────────────────────────────────────── */}
        <section
          style={{
            padding: '88px 0',
            background: 'linear-gradient(135deg, rgba(30,94,255,.08) 0%, transparent 50%)',
            borderBottom: '1px solid rgba(255,255,255,.05)',
          }}
        >
          <div className="container-site text-center">
            <p style={{ fontSize: 11, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2, marginBottom: 16, textTransform: 'uppercase' }}>
              Notre mission
            </p>
            <h2 style={{ fontSize: 'clamp(28px,4vw,48px)', fontWeight: 900, lineHeight: 1.1, letterSpacing: '-1px', color: '#fff', marginBottom: 18, maxWidth: 580, margin: '0 auto 18px' }}>
              Apprends. Applique. Progresse.
            </h2>
            <p style={{ fontSize: 15, color: '#9CA3AF', maxWidth: 480, margin: '0 auto 44px', lineHeight: 1.75 }}>
              Des ressources pratiques pensées pour passer de l&apos;idée à l&apos;action — conçues pour les entrepreneurs africains.
            </p>
            <div className="flex gap-12 justify-center flex-wrap mb-11">
              {[
                ['📘', 'Ebooks & Guides', "Contenus actionnables, pas théoriques"],
                ['🚀', 'Application Directe', "Chaque module se traduit en actions concrètes"],
                ['🌍', 'Contexte Africain', "Pour les réalités du marché francophone"],
              ].map(([e, t, d]) => (
                <div key={t} style={{ maxWidth: 200 }}>
                  <p style={{ fontSize: 32, marginBottom: 10 }}>{e}</p>
                  <p style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 6 }}>{t}</p>
                  <p style={{ fontSize: 12, color: '#6B7280', lineHeight: 1.65 }}>{d}</p>
                </div>
              ))}
            </div>
            <Link href="/produits" className="btn-blue btn-blue-xl">
              EXPLORER LA BOUTIQUE →
            </Link>
          </div>
        </section>

        <WASection />
      </main>
      <Footer />
    </>
  )
}
