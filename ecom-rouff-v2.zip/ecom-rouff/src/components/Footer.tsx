import Link from 'next/link'
import { SITE_CONFIG } from '@/data/config'

export default function Footer() {
  const year = new Date().getFullYear()

  const cols = [
    {
      title: 'Produits',
      links: [
        { label: 'Tous les produits',     href: '/produits' },
        { label: 'WhatsApp & Vente',      href: '/produits?cat=WHATSAPP+%26+VENTE' },
        { label: 'E-Commerce',            href: '/produits?cat=E-COMMERCE' },
        { label: 'IA & Digital',          href: '/produits?cat=IA+%26+DIGITAL' },
      ],
    },
    {
      title: SITE_CONFIG.brandName,
      links: [
        { label: 'À propos',  href: '/a-propos' },
        { label: 'Contact',   href: '/contact' },
        { label: 'Politique de confidentialité', href: '/confidentialite' },
        { label: "Conditions d'utilisation",     href: '/conditions' },
      ],
    },
    {
      title: 'Support',
      links: [
        { label: 'WhatsApp',  href: '/contact' },
        { label: 'Email',     href: '/contact' },
        { label: 'FAQ',       href: '/contact' },
      ],
    },
  ]

  return (
    <footer style={{ background: '#050508', borderTop: '1px solid rgba(255,255,255,.06)', paddingTop: 52 }}>
      <div className="container-site">

        {/* Grid */}
        <div
          className="grid gap-12 pb-12"
          style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', borderBottom: '1px solid rgba(255,255,255,.06)' }}
        >
          {/* Brand */}
          <div>
            <Link href="/" className="flex flex-col gap-1 mb-5 no-underline">
              <span style={{ fontSize: 15, fontWeight: 900, letterSpacing: 1.5, color: '#fff' }}>
                {SITE_CONFIG.brandName}
              </span>
              <span style={{ fontSize: 8, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2.5 }}>
                {SITE_CONFIG.tagline}
              </span>
            </Link>
            <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.75, maxWidth: 220 }}>
              Ebooks, guides et ressources digitales pour développer votre business en Afrique francophone.
            </p>
          </div>

          {/* Colonnes */}
          {cols.map(({ title, links }) => (
            <div key={title}>
              <p style={{ fontSize: 11, fontWeight: 700, color: '#fff', letterSpacing: 1, marginBottom: 18, textTransform: 'uppercase' }}>
                {title}
              </p>
              <div className="flex flex-col gap-3">
                {links.map(({ label, href }) => (
                  <Link key={label} href={href} className="nav-link" style={{ fontSize: 13 }}>
                    {label}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="flex items-center justify-between flex-wrap gap-3 py-5">
          <p style={{ fontSize: 12, color: '#374151' }}>
            © {year} ECOM-ROUFF DIGITAL UNIVERSE. Tous droits réservés.
          </p>
          <div className="flex gap-5">
            <Link href="/confidentialite" className="nav-link" style={{ fontSize: 12 }}>
              Politique de confidentialité
            </Link>
            <Link href="/conditions" className="nav-link" style={{ fontSize: 12 }}>
              {"Conditions d'utilisation"}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
