import { SITE_CONFIG, getWhatsAppLink } from '@/data/config'

export default function WASection() {
  const link = getWhatsAppLink(SITE_CONFIG.whatsappNumber, SITE_CONFIG.whatsappMessage)

  return (
    <section
      className="py-18"
      style={{
        padding: '72px 0',
        borderBottom: '1px solid rgba(255,255,255,.05)',
        background: 'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(16,185,129,.06) 0%, transparent 70%)',
      }}
    >
      <div className="container-site text-center">
        <p style={{ fontSize: 40, marginBottom: 16 }}>💬</p>
        <h2 style={{ fontSize: 'clamp(22px,3vw,32px)', fontWeight: 900, color: '#fff', marginBottom: 12 }}>
          Besoin d&apos;aide ?
        </h2>
        <p style={{ fontSize: 15, color: '#9CA3AF', maxWidth: 420, margin: '0 auto 28px', lineHeight: 1.75 }}>
          Une question sur un produit ou besoin d&apos;aide avant ton achat ? Contacte-nous directement sur WhatsApp.
        </p>
        <a
          href={link}
          target="_blank"
          rel="noreferrer"
          className="btn-blue btn-blue-lg"
          style={{ background: '#16A34A' }}
        >
          NOUS CONTACTER SUR WHATSAPP
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14M12 5l7 7-7 7"/>
          </svg>
        </a>
      </div>
    </section>
  )
}
