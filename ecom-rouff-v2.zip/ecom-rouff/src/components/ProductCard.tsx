import Link from 'next/link'
import type { Product } from '@/types'
import { BADGE_COLORS } from '@/data/config'
import ProductImage from './ProductImage'

interface Props { product: Product }

export default function ProductCard({ product: p }: Props) {
  const badgeColor = p.badge ? (BADGE_COLORS[p.badge] ?? '#3B82F6') : null

  return (
    <Link href={`/produits/${p.slug}`} className="product-card">
      <ProductImage product={p} height="200px" />

      <div className="flex flex-col gap-2.5" style={{ padding: '20px 22px 24px', flex: 1 }}>

        {/* Catégorie + Badge */}
        <div className="flex items-center justify-between gap-2">
          <span style={{ fontSize: 10, fontWeight: 700, color: '#6B7280', letterSpacing: .8, textTransform: 'uppercase' }}>
            {p.category}
          </span>
          {p.badge && badgeColor && (
            <span
              style={{
                fontSize: 10, fontWeight: 800, letterSpacing: 1,
                padding: '3px 9px', borderRadius: 50, textTransform: 'uppercase',
                background: `${badgeColor}22`, color: badgeColor, border: `1px solid ${badgeColor}44`,
              }}
            >
              {p.badge}
            </span>
          )}
        </div>

        {/* Titre */}
        <h3 style={{ fontSize: 16, fontWeight: 700, lineHeight: 1.3, color: '#fff', margin: 0 }}>
          {p.title}
        </h3>

        {/* Description courte */}
        <p style={{ fontSize: 13, color: '#9CA3AF', lineHeight: 1.65, margin: 0, flex: 1 }}>
          {p.shortDesc}
        </p>

        {/* Prix + CTA */}
        <div className="flex items-center justify-between gap-2 flex-wrap mt-1">
          <div>
            <span style={{ fontSize: 17, fontWeight: 800, color: '#fff' }}>{p.price}</span>
            {p.oldPrice && (
              <span style={{ fontSize: 13, color: '#6B7280', textDecoration: 'line-through', marginLeft: 8 }}>
                {p.oldPrice}
              </span>
            )}
          </div>
          <span
            className="btn-blue"
            style={{ padding: '8px 16px', fontSize: 12, gap: 6 }}
          >
            Voir
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </span>
        </div>
      </div>
    </Link>
  )
}
