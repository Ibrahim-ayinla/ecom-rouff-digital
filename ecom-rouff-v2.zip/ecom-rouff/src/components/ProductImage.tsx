import Image from 'next/image'
import type { Product } from '@/types'
import { CATEGORY_GRADIENTS } from '@/data/config'

interface Props {
  product: Product
  height?: string | number
  className?: string
}

export default function ProductImage({ product, height = '200px', className = '' }: Props) {
  const grad = CATEGORY_GRADIENTS[product.category] ?? ['#111', '#1E5EFF']

  return (
    <div
      className={`relative overflow-hidden flex-shrink-0 ${className}`}
      style={{ height }}
    >
      {product.image ? (
        /* Vraie image du produit */
        <Image
          src={product.image}
          alt={product.title}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          priority={false}
        />
      ) : (
        /* Placeholder premium gradient */
        <div
          className="w-full h-full flex flex-col items-center justify-center gap-2"
          style={{ background: `linear-gradient(135deg, ${grad[0]} 0%, ${grad[1]} 100%)` }}
        >
          {/* Grille décorative */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,.04) 1px,transparent 1px),' +
                'linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />
          <span className="relative z-10" style={{ fontSize: 48 }}>
            {product.emoji ?? '📦'}
          </span>
          <div className="relative z-10 text-center px-5">
            <p style={{ fontSize: 9, color: 'rgba(255,255,255,.4)', letterSpacing: 2, textTransform: 'uppercase', marginBottom: 4 }}>
              ECOM-ROUFF
            </p>
            <p style={{ fontSize: 12, fontWeight: 700, color: '#fff', lineHeight: 1.3 }}>
              {product.title}
            </p>
          </div>
          <p
            className="absolute bottom-2 left-0 right-0 text-center"
            style={{ fontSize: 9, color: 'rgba(255,255,255,.2)', letterSpacing: 1 }}
          >
            ← Remplacer par votre image →
          </p>
        </div>
      )}

      {/* Badge DÉMO */}
      {product.isDemo && (
        <div
          className="absolute top-2 right-2 z-10"
          style={{
            background: 'rgba(0,0,0,.75)',
            backdropFilter: 'blur(8px)',
            borderRadius: 6,
            padding: '3px 8px',
            fontSize: 9,
            fontWeight: 800,
            color: '#6B7280',
            letterSpacing: 1,
          }}
        >
          DÉMO
        </div>
      )}

      {/* Overlay gradient bas (pour texte sur vraie image) */}
      {product.image && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'linear-gradient(to top, rgba(0,0,0,.5) 0%, transparent 50%)' }}
        />
      )}
    </div>
  )
}
