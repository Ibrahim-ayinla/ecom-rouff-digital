'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { SITE_CONFIG } from '@/data/config'

const NAV_LINKS = [
  { label: 'Accueil',  href: '/' },
  { label: 'Produits', href: '/produits' },
  { label: 'À propos', href: '/a-propos' },
  { label: 'Contact',  href: '/contact' },
]

export default function Header() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <header
      className="sticky top-0 z-50"
      style={{
        background: 'rgba(10,10,10,.92)',
        backdropFilter: 'blur(24px) saturate(1.5)',
        borderBottom: '1px solid rgba(255,255,255,.06)',
      }}
    >
      <div className="container-site flex items-center justify-between" style={{ height: 68 }}>

        {/* Logo */}
        <Link href="/" className="flex flex-col gap-1 no-underline">
          <span style={{ fontSize: 15, fontWeight: 900, letterSpacing: 1.5, color: '#fff' }}>
            {SITE_CONFIG.brandName}
          </span>
          <span style={{ fontSize: 8, fontWeight: 700, color: '#1E5EFF', letterSpacing: 2.5 }}>
            {SITE_CONFIG.tagline}
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(({ label, href }) => (
            <Link
              key={href}
              href={href}
              className={`nav-link ${pathname === href ? 'active' : ''}`}
            >
              {label}
            </Link>
          ))}
        </nav>

        {/* CTA + hamburger */}
        <div className="flex items-center gap-3">
          <Link href="/produits" className="btn-blue hidden md:inline-flex" style={{ padding: '10px 20px', fontSize: 12 }}>
            DÉCOUVRIR LES PRODUITS
          </Link>
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden flex items-center justify-center p-1"
            style={{ color: '#fff' }}
            aria-label="Menu"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              {open
                ? <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>
                : <><line x1="3" y1="7" x2="21" y2="7"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="17" x2="21" y2="17"/></>
              }
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div style={{ background: '#0A0A0A', borderTop: '1px solid rgba(255,255,255,.06)', padding: '8px 24px 24px' }}>
          {NAV_LINKS.map(({ label, href }) => (
            <Link
              key={href}
              href={href}
              className={`nav-link block py-3 text-base border-b`}
              style={{ borderColor: 'rgba(255,255,255,.05)', width: '100%' }}
              onClick={() => setOpen(false)}
            >
              {label}
            </Link>
          ))}
          <Link href="/produits" className="btn-blue mt-4 w-full" style={{ padding: '14px 0', fontSize: 14 }}
            onClick={() => setOpen(false)}>
            DÉCOUVRIR LES PRODUITS
          </Link>
        </div>
      )}
    </header>
  )
}
